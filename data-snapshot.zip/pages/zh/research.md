---
title: "研究方向"
nav: true
order: 2
slug: "research"
description: "研究方向与代表工作"
---

> 研究记录保持简短：只留下还能被复现、被检验的部分。

## 方向一：高效推理

大模型推理的瓶颈在显存带宽而非算力。我关注：

- **投机解码**（speculative decoding）的系统侧优化
- KV cache 的压缩与分页调度
- 单机多卡的流水并行切分

一个典型的权衡：batch size 翻倍带来的吞吐提升，会被 KV cache 占用反噬——$O(B \cdot L \cdot d)$ 的显存增长不是闹着玩的。

## 方向二：可复现的评测

评测集污染是这个时代的慢性病。我在做一套"活"的评测流水线：

::::grid{cols=2}
:::cell
**问题**

- 静态评测集被爬进训练语料
- 单次 run 的方差被当成结论
:::
:::cell
**做法**

- 按周滚动生成新题
- 报告分布而非点估计
:::
::::

## 代表工作

::ghcard{repo="huggingface/transformers"}

示例站点中，这里展示的是日常依赖的基础设施；换成你自己的项目即可。
